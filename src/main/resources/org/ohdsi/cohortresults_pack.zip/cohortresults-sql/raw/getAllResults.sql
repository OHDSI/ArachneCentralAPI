select *
from @tableQualifier.heracles_results 
where cohort_definition_id = @cohortDefinitionId
