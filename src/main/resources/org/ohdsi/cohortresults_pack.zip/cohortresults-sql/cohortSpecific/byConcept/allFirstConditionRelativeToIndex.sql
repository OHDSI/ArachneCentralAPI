WITH report_scope as (
    select cohort_definition_id, analysis_id,count_value,
           CAST(CASE WHEN isNumeric(stratum_1) = 1 THEN stratum_1 ELSE null END AS INT) AS stratum_1,
           CAST(CASE WHEN isNumeric(stratum_2) = 1 THEN stratum_2 ELSE null END AS INT) AS stratum_2
    from @ohdsi_database_schema.heracles_results where  cohort_definition_id = @cohortDefinitionId and analysis_id in (1805,1806,1820,1821)
)
SELECT hr1.cohort_definition_id,
       'First' AS record_type, 
       c1.concept_id, 
       c1.concept_name, 
       hr1.duration, 
       hr1.count_value, 
       CASE 
         WHEN t1.count_value > 0 THEN 1.0 * hr1.count_value / t1.count_value 
         ELSE 0 
       END     AS pct_persons 
FROM   (SELECT cohort_definition_id, 
               stratum_1      AS concept_id,
               stratum_2 * 30 AS duration,
               count_value 
        FROM   report_scope
        WHERE  analysis_id IN ( 1820 ) 
               AND cohort_definition_id = @cohortDefinitionId
               AND stratum_2 * 30 BETWEEN -1000 AND 1000) hr1
       INNER JOIN (SELECT -1 * stratum_1 * 30 AS duration,
                          Sum(count_value) OVER ( ORDER BY -1* stratum_1 *30 ASC) AS count_value
                   FROM  (
                                             select stratum_1, max(count_value) as count_value
                                                  from
                                                  (
                                                  select row_number() over (order by analysis_id) as stratum_1, 0 as count_value
                                                  from report_scope
                                                  where analysis_id = 1805
                                                  and cohort_definition_id = @cohortDefinitionId
                                                  union
                                                  select stratum_1, count_value
                                                  from report_scope
                                                  where analysis_id = 1805
                                                  and cohort_definition_id = @cohortDefinitionId
                                                  ) t1
                                                  where stratum_1<=10 or count_value > 0
                                                  group by stratum_1
                                             ) t0
                                             WHERE stratum_1 > 0
                   UNION 
                   SELECT stratum_1 * 30 AS duration,
                          t1.count_value - Sum(hr1.count_value) 
                          OVER ( 
                            partition BY hr1.cohort_definition_id 
                            ORDER BY stratum_1 *30 ASC) AS count_value
                   FROM   report_scope hr1
                          INNER JOIN (SELECT cohort_definition_id, 
                                             Sum(count_value) AS count_value 
                                      FROM 
                          report_scope
                                      WHERE  analysis_id = 1806 
                                             AND cohort_definition_id = @cohortDefinitionId 
                                      GROUP  BY cohort_definition_id) t1 
                                  ON hr1.cohort_definition_id = 
                                     t1.cohort_definition_id 
                   WHERE  hr1.analysis_id IN ( 1806 ) 
                          AND hr1.cohort_definition_id = @cohortDefinitionId) t1
               ON  hr1.duration = t1.duration 
       INNER JOIN (SELECT stratum_1 AS concept_id,
                          Sum(count_value) AS count_value
                   FROM   report_scope
                   WHERE  analysis_id IN ( 1820 ) 
                           GROUP  BY stratum_1 HAVING Sum(report_scope.count_value) > @minCovariatePersonCount
                   ) ct1 
               ON hr1.concept_id = ct1.concept_id
       INNER JOIN @cdm_database_schema.concept c1 
               ON hr1.concept_id = c1.concept_id 
WHERE  t1.count_value > @minIntervalPersonCount
UNION 
SELECT hr1.cohort_definition_id, 
       'All' AS record_type, 
       c1.concept_id, 
       c1.concept_name, 
       hr1.duration, 
       hr1.count_value, 
       CASE 
         WHEN t1.count_value > 0 THEN 1.0 * hr1.count_value / t1.count_value 
         ELSE 0 
       END   AS pct_persons 
FROM   (SELECT cohort_definition_id, 
               stratum_1 AS concept_id,
               stratum_2 * 30 AS duration,
               count_value 
        FROM   report_scope
        WHERE  analysis_id IN ( 1821 ) 
               AND cohort_definition_id = @cohortDefinitionId
               AND stratum_2 * 30 BETWEEN -1000 AND 1000
               ) hr1 
       INNER JOIN (SELECT -1 * stratum_1 * 30 AS duration,
                          Sum(count_value) 
                            OVER ( 
                              ORDER BY -1* stratum_1 *30 ASC) AS
              count_value 
                   FROM  (
                                             select stratum_1, max(count_value) as count_value
                                                  from
                                                  (
                                                  select row_number() over (order by analysis_id) as stratum_1, 0 as count_value
                                                  from report_scope
                                                  where analysis_id = 1805
                                                  and cohort_definition_id = @cohortDefinitionId
                                                  union
                                                  select stratum_1, count_value
                                                  from report_scope
                                                  where analysis_id = 1805
                                                  and cohort_definition_id = @cohortDefinitionId
                                                  ) t1
                                                  where stratum_1<=10 or count_value > 0
                                                  group by stratum_1
                                             ) t0
                                             WHERE stratum_1 > 0
                   UNION 
                   SELECT stratum_1 * 30 AS duration,
                          t1.count_value - Sum(hr1.count_value) 
                          OVER ( 
                            partition BY hr1.cohort_definition_id 
                            ORDER BY stratum_1 * 30 ASC) AS
                          count_value 
                   FROM   report_scope hr1
                          INNER JOIN (SELECT cohort_definition_id, 
                                             Sum(count_value) AS count_value 
                                      FROM 
                          report_scope
                                      WHERE  analysis_id = 1806 
                                             AND cohort_definition_id = @cohortDefinitionId 
                                      GROUP  BY cohort_definition_id) t1 
                                  ON hr1.cohort_definition_id = 
                                     t1.cohort_definition_id 
                   WHERE  hr1.analysis_id IN ( 1806 ) 
                          AND hr1.cohort_definition_id IN 
                              ( @cohortDefinitionId ) ) t1
               ON  hr1.duration = t1.duration 
       INNER JOIN (SELECT stratum_1 AS concept_id,
                          Sum(count_value)           AS count_value 
                   FROM   report_scope
                   WHERE  analysis_id IN ( 1820 ) 
                           GROUP  BY stratum_1 HAVING Sum(report_scope.count_value) > @minCovariatePersonCount
                   ) ct1 
               ON hr1.concept_id = ct1.concept_id 
       INNER JOIN @cdm_database_schema.concept c1 
               ON hr1.concept_id = c1.concept_id 
WHERE  t1.count_value > @minIntervalPersonCount

ORDER BY concept_id, record_type, duration
